$(function(){
	$(".LayoutLeft li").hover(function(){
		$('ul:first',this).show();
	}, function(){
	$('ul:first',this).hide();
	});
	$(".LayoutLeft>li:has(ul)>a").each( function() {
		$(this).html( $(this).html()+' &or;' );
	});
	$(".LayoutLeft ul li:has(ul)")
		.find("a:first")
		.append("<p style='float:right;margin:-3px'>&#9656;</p>");

	$(".LayoutRight li").hover(function(){
		$('ul:first',this).show();
	}, function(){
	$('ul:first',this).hide();
	});
	$(".LayoutRight>li:has(ul)>a").each( function() {
		$(this).html( $(this).html()+' &or;' );
	});
	$(".LayoutRight ul li:has(ul)")
		.find("a:first")
		.append("<p style='float:right;margin:-3px'>&#9656;</p>");

	$(".ProductNaviUl li").hover(function(){
		$('ul:first',this).show();
	}, function(){
	$('ul:first',this).hide();
	});
});