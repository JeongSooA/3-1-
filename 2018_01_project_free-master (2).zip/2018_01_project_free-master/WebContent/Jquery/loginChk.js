//로그인시 id, pw확인
$(function(){
	$("#login_submit_btn").click(function(){
		if($("#login_usr_id").val()==""||$("#login_usr_pw").val()==""){
			if($("#login_usr_id").val()==""){
				alert("회원 ID를 입력해 주세요");
				$("#login_usr_id").focus();
				event.preventDefault();
			}else{
				alert("비밀번호를 입력해 주세요");
				$("#login_usr_pw").focus();
				event.preventDefault();
			}
		}
	});
});